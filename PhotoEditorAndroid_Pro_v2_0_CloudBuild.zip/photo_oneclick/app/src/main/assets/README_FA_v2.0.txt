Photo Editor Android Pro v2.0

این نسخه بر پایه نسخه 1.5 ساخته شده و ابزارهای زیر را اضافه می‌کند:
- Brush Preset: Basic, Ink, Soft, Airbrush, Pencil, Marker, Chalk, Eraser
- ابزار برش (Crop)
- انتخاب ناحیه (Selection)
- جابه‌جایی (Move)
- متن (Text)
- گرادیان (Gradient)
- Healing و Clone به‌عنوان ابزارهای حرفه‌ای پایه
- فیلترهای Grayscale, Sepia, Invert, Contrast, Brightness, Blur/Saturate در رابط
- Undo / Redo
- Duplicate Layer و Merge Down در رابط لایه‌ها
- کنترل اندازه، شفافیت و رنگ قلم
- حفظ قابلیت‌های PSD/PSB و لایه‌های نسخه 1.5

توجه:
این پروژه یک ویرایشگر مستقل با رابط و قابلیت‌های مشابه نرم‌افزارهای حرفه‌ای است و کپی مستقیم از Photoshop نیست.
برای ساخت APK، پروژه را در Android Studio باز کنید و Build > Build APK(s) را اجرا کنید.
