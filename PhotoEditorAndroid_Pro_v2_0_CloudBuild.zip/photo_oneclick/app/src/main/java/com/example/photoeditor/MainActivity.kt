package com.example.photoeditor

import android.app.Activity
import android.os.Bundle
import android.webkit.*
import android.content.Intent
import android.net.Uri
import android.util.Base64
import android.provider.MediaStore
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView

    private val picker = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            try {
                contentResolver.takePersistableUriPermission(
                    it, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            val bytes = contentResolver.openInputStream(it)?.use { input ->
                input.readBytes()
            } ?: return@let
            val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
            val name = it.lastPathSegment ?: "document.psd"
            val safeName = name.replace("'", "")
            web.evaluateJavascript(
                "window.receivePSD('$b64', '$safeName');", null
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(AndroidBridge(), "Android")
        web.loadUrl("file:///android_asset/editor.html")
        setContentView(web)
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun openPSD() {
            runOnUiThread {
                picker.launch(arrayOf(
                    "application/octet-stream",
                    "image/vnd.adobe.photoshop",
                    "*/*"
                ))
            }
        }

        @JavascriptInterface
        fun savePSD(base64: String, filename: String) {
            try {
                val data = Base64.decode(base64, Base64.DEFAULT)
                val values = android.content.ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME,
                        if (filename.endsWith(".psd", true)) filename else "$filename.psd")
                    put(MediaStore.Downloads.MIME_TYPE, "image/vnd.adobe.photoshop")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI, values
                ) ?: return
                contentResolver.openOutputStream(uri)?.use { it.write(data) }
                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
            } catch (_: Exception) {}
        }
    }
}
