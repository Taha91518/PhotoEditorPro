@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul

echo ================================================
echo   Photo Editor Pro v2.0 - One Click APK Build
echo ================================================
echo.
echo This will install/download only the tools needed to build the APK.
echo Android Studio is NOT required.
echo Internet connection is required on the first run.
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_APK.ps1"
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Please send me a screenshot of this window.
  pause
  exit /b 1
)
echo.
echo ================================================
echo APK created successfully:
echo %~dp0PhotoEditorPro-v2.0-debug.apk
echo ================================================
pause
