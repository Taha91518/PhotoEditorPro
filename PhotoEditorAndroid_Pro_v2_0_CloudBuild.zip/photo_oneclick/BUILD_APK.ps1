$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

function Say($s) { Write-Host $s -ForegroundColor Cyan }
function Ok($s) { Write-Host $s -ForegroundColor Green }

# The previous version depended on winget. This version does NOT require winget.
# It installs missing Java 17 and Android CLI directly for the current Windows user.

Say 'Photo Editor Pro v2.0 - One Click APK Build'
Say 'This version does NOT require Android Studio or winget.'
Say 'Internet is required on the first run.'
Write-Host ''

Say 'Step 1/4 - Checking Java 17...'
$javaCmd = Get-Command java -ErrorAction SilentlyContinue
$javaHome = $env:JAVA_HOME
$javaOk = $false
if ($javaCmd) {
    $v = (& java -version 2>&1 | Select-Object -First 1)
    if ($v -match 'version "17\.' -or $v -match 'version "1\.17\.') { $javaOk = $true; Ok ('Java 17 found: ' + $v) }
}

if (-not $javaOk) {
    Say 'Java 17 was not found. Downloading Eclipse Temurin 17 automatically...'
    $javaRoot = Join-Path $PSScriptRoot 'tools\jdk17'
    New-Item -ItemType Directory -Force -Path $javaRoot | Out-Null
    $api = 'https://api.adoptium.net/v3/assets/latest/17/hotspot?architecture=x64&image_type=jdk&os=windows&vendor=eclipse&heap_size=normal&jvm_impl=hotspot'
    $assets = Invoke-RestMethod -Uri $api -UseBasicParsing
    $pkg = $assets[0].binary.package.link
    if (-not $pkg) { throw 'Could not find a Java 17 download from Adoptium.' }
    $zip = Join-Path $env:TEMP 'temurin17.zip'
    Say 'Downloading Java 17...'
    Invoke-WebRequest -Uri $pkg -OutFile $zip -UseBasicParsing
    Say 'Extracting Java 17...'
    Get-ChildItem $javaRoot -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    Expand-Archive -Path $zip -DestinationPath $javaRoot -Force
    Remove-Item $zip -Force -ErrorAction SilentlyContinue
    $javaExe = Get-ChildItem $javaRoot -Filter java.exe -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $javaExe) { throw 'Java 17 was downloaded but java.exe could not be located.' }
    $javaHome = Split-Path (Split-Path $javaExe.FullName -Parent) -Parent
    $env:JAVA_HOME = $javaHome
    $env:Path = "$javaHome\bin;$env:Path"
    Ok 'Java 17 is ready.'
}
if (-not $env:JAVA_HOME -and $javaHome) { $env:JAVA_HOME = $javaHome }

Say 'Step 2/4 - Installing Android SDK command-line tools...'
$sdk = Join-Path $env:LOCALAPPDATA 'Android\Sdk'
New-Item -ItemType Directory -Force -Path $sdk | Out-Null
$env:ANDROID_HOME = $sdk
$env:ANDROID_SDK_ROOT = $sdk

# Use Google's official command-line tools ZIP.
# Some networks return HTTP 404 for dl.google.com even when the official file exists.
# Fixed5 supports a local ZIP fallback: place the official ZIP beside BUILD_APK.bat.
$cmdlineRoot = Join-Path $sdk 'cmdline-tools\latest'
$sdkmanager = Join-Path $cmdlineRoot 'bin\sdkmanager.bat'
if (-not (Test-Path $sdkmanager)) {
    $toolsZip = Join-Path $PSScriptRoot 'commandlinetools-win-15859902_latest.zip'
    $officialUrl = 'https://dl.google.com/android/repository/commandlinetools-win-15859902_latest.zip'

    if (-not (Test-Path $toolsZip)) {
        Say 'Downloading official Google Android command-line tools (about 156 MB)...'
        Say 'If Google returns 404 on this computer, the script will open the official download page.'
        try {
            & curl.exe -fL --retry 2 --retry-delay 2 --connect-timeout 20 --max-time 900 --url $officialUrl --output $toolsZip
        } catch { }
        if (-not (Test-Path $toolsZip) -or (Get-Item $toolsZip).Length -lt 100MB) {
            Remove-Item $toolsZip -Force -ErrorAction SilentlyContinue
            Say 'Google download was not reachable from this network.'
            Say 'Opening the official Android download page in your browser...'
            Start-Process 'https://developer.android.com/studio'
            Write-Host ''
            Write-Host 'Please download: commandlinetools-win-15859902_latest.zip' -ForegroundColor Yellow
            Write-Host 'Save that ZIP in THIS folder, next to BUILD_APK.bat, then press Enter.' -ForegroundColor Yellow
            Read-Host 'Press Enter after the ZIP has been downloaded'
        }
    }

    if (-not (Test-Path $toolsZip) -or (Get-Item $toolsZip).Length -lt 100MB) {
        throw 'Android command-line tools ZIP was not found. Download commandlinetools-win-15859902_latest.zip from the official Android page and put it beside BUILD_APK.bat.'
    }

    $tmpTools = Join-Path $env:TEMP 'android-cmdline-tools-extract'
    if (Test-Path $tmpTools) { Remove-Item $tmpTools -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $tmpTools | Out-Null
    Say 'Extracting Android command-line tools...'
    Expand-Archive -Path $toolsZip -DestinationPath $tmpTools -Force
    New-Item -ItemType Directory -Force -Path (Join-Path $sdk 'cmdline-tools') | Out-Null
    if (Test-Path $cmdlineRoot) { Remove-Item $cmdlineRoot -Recurse -Force }
    Move-Item (Join-Path $tmpTools 'cmdline-tools') $cmdlineRoot
    Remove-Item $tmpTools -Recurse -Force -ErrorAction SilentlyContinue
}
if (-not (Test-Path $sdkmanager)) { throw 'sdkmanager.bat was not found after extracting the Android command-line tools.' }
$env:Path = "$(Split-Path $sdkmanager -Parent);$env:Path"
Ok 'Android command-line tools are ready.'

Say 'Step 3/4 - Installing Android SDK Platform 35, Build Tools and Platform Tools...'
Say 'Accepting Android SDK licenses automatically...'
cmd.exe /c "(echo y&echo y&echo y&echo y&echo y&echo y&echo y&echo y) | `"$sdkmanager`" --licenses" | Out-Null
& $sdkmanager --sdk_root=$sdk 'platforms;android-35' 'build-tools;35.0.0' 'platform-tools'
if ($LASTEXITCODE -ne 0) { throw 'Android SDK package installation failed.' }
Ok 'Android SDK is ready.'

Say 'Step 4/4 - Downloading Gradle and building the APK...'
$gradleVersion = '8.11.1'
$gradleDir = Join-Path $PSScriptRoot ("gradle-$gradleVersion")
$gradleExe = Join-Path $gradleDir 'bin\gradle.bat'
if (-not (Test-Path $gradleExe)) {
    $zip = Join-Path $env:TEMP ("gradle-$gradleVersion-bin.zip")
    Say 'Downloading Gradle...'
    Invoke-WebRequest ("https://services.gradle.org/distributions/gradle-$gradleVersion-bin.zip") -OutFile $zip -UseBasicParsing
    Expand-Archive -Path $zip -DestinationPath $PSScriptRoot -Force
    Remove-Item $zip -Force -ErrorAction SilentlyContinue
}
if (-not (Test-Path $gradleExe)) { throw 'Gradle could not be downloaded/extracted.' }

if ($env:JAVA_HOME) { $env:JAVA_HOME = $env:JAVA_HOME }
& $gradleExe --no-daemon --stacktrace assembleDebug
if ($LASTEXITCODE -ne 0) { throw 'Gradle build failed.' }

$apk = Join-Path $PSScriptRoot 'app\build\outputs\apk\debug\app-debug.apk'
if (-not (Test-Path $apk)) { throw 'APK was not found after a successful Gradle build.' }
Copy-Item $apk (Join-Path $PSScriptRoot 'PhotoEditorPro-v2.0-debug.apk') -Force
Ok 'SUCCESS! PhotoEditorPro-v2.0-debug.apk has been created.'
Ok ('Location: ' + (Join-Path $PSScriptRoot 'PhotoEditorPro-v2.0-debug.apk'))
