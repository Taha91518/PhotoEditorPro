Photo Editor Pro v2.0 - Fixed5

This version fixes the repeated Google 404 problem.
If dl.google.com works, it downloads the official Android command-line tools automatically.
If your network returns 404, it opens the official Android download page and asks you to download:
commandlinetools-win-15859902_latest.zip
Then put that ZIP beside BUILD_APK.bat and press Enter. The rest is automatic.
